package pkg;

public class Mod implements IOperacaoInteira{
	@Override
	public int executar(int v1, int v2) {
		int mod,resto;
		
		resto = v1/v2;
		mod = v1 - (resto*v2);
		
		return mod;
	}

}
