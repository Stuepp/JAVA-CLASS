package pkg;

public class Multiplicacao extends Soma{
	public int multiplicar(int v1,int v2) {
		int mult = 0;
		if(v1 == 0 || v2 == 0) {
			return 0;
		}else if(v1 == 1) {
			return v2;
		}else if(v2 == 1) {
			return v1;
		}else if(v1 > v2) {
			for(int i = 0; i < v2; i++) {
				mult += super.executar(0, v1);
			}
		}else if(v2 >= v1) {
			for(int i = 0; i < v1; i++) {
				mult += super.executar(0, v2);
			}
		}
		
		return mult;
	}
}
