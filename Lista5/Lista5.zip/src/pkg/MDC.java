package pkg;

public class MDC implements IOperacaoInteira{
	@Override
	public int executar(int v1, int v2) {
		if(v1 == 0 || v2 == 0) {
			return 0;
		}
		int d1, d2;
		if(v1%2 == 0 && v2 %2 == 0) {
			d1 = v1/2;
			d2 = v2/2;
		}
		
		return 0;
	}

}
