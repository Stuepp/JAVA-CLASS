package pkg;

public class Soma implements IOperacaoInteira{
	@Override
	public int executar(int v1, int v2) {
		int soma = v1 + v2;
		
		return soma;
	}
}
