package pkg;

import java.util.Scanner;

public class Main {

	private static Scanner s = new Scanner(System.in);
	private static Soma soma;
	private static Multiplicacao mult;
	private static MDC mdc;
	private static Mod mod;
	
	public static void main(String[] args) {	
		int opcao = 1;
		while(opcao != 0) {
			menu();
			System.out.println("Deseja continuar?\n0 - N�o\n1 - Sim");
			opcao = Integer.parseInt(s.nextLine());
		}
	}
	public static void menu() {
		int a,b;
		System.out.println("(01) - Soma"
				+ "\n(02) - Multiplica��o"
				+ "\n(03) - M�ximo divisor comum"
				+ "\n(04) - mod");
		int escolha = Integer.parseInt(s.nextLine());
		switch(escolha) {
			case 1:
				soma = new Soma();
				System.out.println("Digite o valor de a:");
				a = Integer.parseInt(s.nextLine());
				System.out.println("Digite o valor de b:");
				b = Integer.parseInt(s.nextLine());
				System.out.println(soma.executar(a, b));
				break;
			case 2:
				mult = new Multiplicacao();
				System.out.println("Digite o valor de a:");
				a = Integer.parseInt(s.nextLine());
				System.out.println("Digite o valor de b:");
				b = Integer.parseInt(s.nextLine());
				System.out.println(mult.multiplicar(a, b));
				break;
			case 3:
				mdc = new MDC();
				break;
			case 4:
				mod = new Mod();
				System.out.println("Digite o valor de a:");
				a = Integer.parseInt(s.nextLine());
				System.out.println("Digite o valor de b:");
				b = Integer.parseInt(s.nextLine());
				System.out.println(mod.executar(a,b));
				break;
			default:
				break;
		}
	}
}
