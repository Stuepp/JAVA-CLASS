package pkg;

public interface IOperacaoInteira {
	public int executar(int v1, int v2);
}
